# Akhilesh Gay — prototype

Developed by Arbaj.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser.

This is a front-end prototype only. It uses fictional sample profiles and in-memory demo interactions. It has no backend, real accounts, real matching, server chat, age verification, moderation service, or production security.

## Before any real launch
A real dating service must be restricted to adults (18+), use robust age assurance, protect sensitive identity and location data, provide consent-based messaging, block/report workflows, moderation and abuse response, secure authentication, data deletion, and legal/privacy review. Do not use real people's personal data in this prototype.


## Welcome intro update
The first screen now shows the photo you supplied, with an official Narendra Modi portrait as the background (loaded from Wikimedia Commons). The funny tune is an original synthesized melody and starts only after the user taps the button, because browsers block autoplay. Keep the `assets` folder beside `index.html`.
